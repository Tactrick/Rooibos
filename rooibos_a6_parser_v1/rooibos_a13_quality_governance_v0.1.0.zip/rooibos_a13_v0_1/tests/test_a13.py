import json, sqlite3, unittest
from rooibos_a13 import *

POLICIES = {"src": SourcePolicy("src", ["endpoint"])}
def rec(kind="a1_discovery", payload=None, **kw):
    payload = payload if payload is not None else ({"chain":"solana", "mint":"So11111111111111111111111111111111111111112", "symbol":"SOL"} if kind == "a1_discovery" else {})
    base = dict(record_id="r1", dataset_type=kind, chain="solana", mint="So11111111111111111111111111111111111111112", source_id="src", endpoint_id="endpoint", run_id="run", raw_response_id="raw", observed_at="2026-11-09T12:00:00Z", normalization_version="v1", content_hash=canonical_hash(payload), payload=payload, source_record_index=0)
    base.update(kw); return EvidenceRecord(**base)

class A13Tests(unittest.TestCase):
    def test_valid_a1(self): self.assertEqual(assess_record(rec(), POLICIES, assessed_at="2026-11-09T12:01:00Z").status, "valid")
    def test_unapproved_endpoint_rejected(self): self.assertEqual(assess_record(rec(endpoint_id="unknown"), POLICIES, assessed_at="x").status, "rejected")
    def test_hash_mismatch_rejected(self): self.assertEqual(assess_record(rec(content_hash="0"*64), POLICIES, assessed_at="x").status, "rejected")
    def test_case_sensitive_mint_mismatch(self):
        p={"chain":"solana", "mint":"so11111111111111111111111111111111111111112"}
        self.assertEqual(assess_record(rec(payload=p), POLICIES, assessed_at="x").status, "rejected")
    def test_sparse_discovery_warns(self):
        p={"chain":"solana", "mint":"So11111111111111111111111111111111111111112"}
        self.assertEqual(assess_record(rec(payload=p), POLICIES, assessed_at="x").status, "valid_with_warnings")
    def test_a2_requires_semantics(self):
        self.assertEqual(assess_record(rec("a2_market", {"metric":"price"}), POLICIES, assessed_at="x").status, "rejected")
    def test_a2_pool_requires_market_id(self):
        p={"metric":"price", "value":1.0, "unit":"USD", "measurement_kind":"observed", "market_scope":"pool_specific"}
        self.assertEqual(assess_record(rec("a2_market", p), POLICIES, assessed_at="x").status, "rejected")
    def test_a6_forming_candle_rejected(self):
        p={"open_time_ms":0,"open":1,"high":2,"low":0.5,"close":1.5,"volume":3,"interval_ms":900000,"candle_status":"forming","volume_unit":"token"}
        self.assertEqual(assess_record(rec("a6_ohlcv",p), POLICIES, assessed_at="x").status, "rejected")
    def test_a6_bad_ohlc_rejected(self):
        p={"open_time_ms":0,"open":1,"high":0.8,"low":0.5,"close":1.5,"volume":3,"interval_ms":900000,"candle_status":"closed","volume_unit":"token"}
        self.assertEqual(assess_record(rec("a6_ohlcv",p), POLICIES, assessed_at="x").status, "rejected")
    def test_warning_snapshot_requires_opt_in(self):
        a=RecordAssessment("r1","valid_with_warnings",(),"now")
        self.assertEqual(decide_snapshot("s","a1_discovery",[a],decided_at="now").dataset_status,"quarantined")
        self.assertEqual(decide_snapshot("s2","a1_discovery",[a],decided_at="now",allow_warnings=True).dataset_status,"approved_with_warnings")
    def test_conflict_quarantines(self):
        a=RecordAssessment("r1","valid",(),"now")
        self.assertEqual(decide_snapshot("s","a1_discovery",[a],decided_at="now",conflict_record_ids={"r1"}).dataset_status,"quarantined")
    def test_missing_expected_record_quarantines(self):
        a=RecordAssessment("r1","valid",(),"now")
        self.assertEqual(decide_snapshot("s","a1_discovery",[a],decided_at="now",expected_record_ids={"r1","r2"}).dataset_status,"quarantined")
    def test_append_only_db(self):
        c=sqlite3.connect(":memory:"); apply_migration_006(c)
        a=RecordAssessment("r1","valid",(),"now")
        self.assertTrue(store_assessment(c,a,"a1","h1")); self.assertFalse(store_assessment(c,a,"a1","h1"))
        with self.assertRaises(sqlite3.IntegrityError): c.execute("UPDATE a13_record_assessments SET status='rejected'")
        d=decide_snapshot("s","a1_discovery",[a],decided_at="now")
        self.assertTrue(store_decision(c,d))
        with self.assertRaises(sqlite3.IntegrityError): c.execute("DELETE FROM a13_snapshot_decisions")

if __name__ == "__main__": unittest.main()
