# Rooibos A13 — Data Quality, Provenance & Snapshot Governance v0.1.0

**Status:** implemented as a provider-neutral offline validation component. Not deployed and not integrated into the main 001–005 migration runner, collectors, Chart Engine or agent runtime.

## Purpose and boundary
A13 independently assesses normalized A1 discovery, A2 market/liquidity and A6 OHLCV evidence. It produces immutable record assessments and append-only snapshot decisions. It does not collect data, call Moby, access credentials, rank tokens, make investment decisions, create paper positions, or alter A1/A2/A6 evidence.

The validator accepts a deliberately small normalized evidence envelope (`EvidenceRecord`). The integration layer must project source data into this envelope without losing the original raw-response reference and provenance. A13 does not infer provider field mappings.

## Validation contract

Every record is checked for:
- Required identity and provenance: chain, exact mint, source, endpoint, run, raw-response ID, observed time, normalization version, content hash.
- Active source registration and endpoint-specific approval (default deny).
- Payload content hash integrity.
- Dataset-specific semantic requirements.

### A1 discovery
- Exact chain + mint match; Solana mint case is significant.
- Sparse optional metadata is a warning, not a rejection. Discovery is not a safety, legitimacy or eligibility judgement.

### A2 market/liquidity
- Requires metric, value, unit, measurement kind and market scope.
- Distinguishes observed, estimated and unknown; pool-specific observations require a market identity.
- Does not average observations or choose a preferred source.

### A6 OHLCV
- Requires timestamps, interval, OHLCV values and candle status.
- Rejects forming candles and invalid OHLC relationships.
- Missing volume units and interval alignment issues are warnings; comparisons must not silently blend units or scopes.

## Snapshot decision rules
- `approved_for_research`: all records valid, complete, no unresolved conflict.
- `approved_with_warnings`: only when caller explicitly sets `allow_warnings=True`; no errors, incomplete records or conflicts.
- `quarantined`: any rejected/incomplete/duplicate/conflicting record, missing expected record, unresolved conflict, or unaccepted warning.
- `rejected` is reserved in the status vocabulary for future policy-level hard rejection; v0.1.0 uses quarantine for failed dataset snapshots to preserve evidence for review.

A source disagreement is never averaged away. The caller must supply conflict record IDs when an upstream comparison detects a disagreement. Independent source identity is controlled by the source registry; different endpoints under one source are not independent corroboration. This version does not calculate cross-source consensus or decide which source is correct.

## Append-only persistence
Migration 006 creates:
- `a13_record_assessments`
- `a13_snapshot_decisions`

Both have update/delete protection. This migration is additive and does not modify A1/A2/A6 records. Apply only after 001–005 have been integrated and verified. The main migration runner and existing database filename must be preserved; this add-on's helper is for isolated tests only.

## Critical integration limitation
A13 does not yet enforce a read gate in Chart Engine or agent runtime. The downstream integration must reject any snapshot unless its persisted decision is `approved_for_research` or explicitly permitted `approved_with_warnings`, and must verify snapshot hash, record membership, policy version and freshness. Raw collector outputs must never bypass that gate. Until this is implemented, A13 approval is a data artifact, not an operational access-control boundary.

A1 v0.1.0 stores its own `DiscoveryObservation` structure; A2 v1.0 stores its own observation structure; A6 has its own candle model. Their concrete projection adapters into this A13 envelope have not been written or tested. No claim of integrated A1–A2–A6 acceptance is made.

## Tests
```bash
python -m unittest discover -s tests -v
python -m compileall -q rooibos_a13 tests
```

13 deterministic unit tests cover provenance and endpoint gating, content hash mismatch, exact mint identity, sparse A1 metadata, A2 semantic and pool identity checks, A6 OHLCV integrity and forming-candle rejection, warning opt-in, missing expected records, conflict quarantine and append-only persistence.
