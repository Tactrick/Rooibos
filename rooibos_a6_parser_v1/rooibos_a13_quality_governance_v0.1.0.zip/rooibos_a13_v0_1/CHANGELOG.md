# Changelog

## 0.1.0 — 2026-11-09
- Initial offline A13 evidence validator and snapshot decision engine.
- Dataset-specific checks for A1, A2 and A6 normalized records.
- Default-deny source/endpoint registry checks and content hash verification.
- Append-only SQLite persistence and standalone migration 006.
- 13 deterministic unit tests.
